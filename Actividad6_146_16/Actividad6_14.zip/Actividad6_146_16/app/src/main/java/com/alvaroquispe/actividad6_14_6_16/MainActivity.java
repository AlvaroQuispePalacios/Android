package com.alvaroquispe.actividad6_14_6_16;

import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private TextView sortida;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sortida = (TextView) findViewById(R.id.sortida);
        SensorManager sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);

        List<Sensor> llistaSensors = sensorManager.getSensorList(Sensor.TYPE_ALL);
        for(Sensor sensor: llistaSensors) {
            log(sensor.getName());
        }
    }
    private void log(String string) {
        sortida.append(string + "\n");
    }
}
